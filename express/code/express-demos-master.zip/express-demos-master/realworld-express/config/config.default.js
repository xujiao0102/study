/**
 * 默认配置
 */

module.exports = {
  dbUri: 'mongodb://10.1.192.43:27017/realworld',
  jwtSecret: '13a054c8-39ea-11eb-adc1-0242ac120002',
  sessionSecret: '5290c3b1-eabf-47f7-9e7b-bc51666210c9'
}
