/**
 * 默认配置
 */

module.exports = {
  dbUri: 'mongodb://10.1.192.169:27017/realworld',
  jwtSecret: '13a054c8-39ea-11eb-adc1-0242ac120002'
}
